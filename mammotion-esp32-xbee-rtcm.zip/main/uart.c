/*
 * This file is part of the ESP32-XBee distribution (https://github.com/nebkat/esp32-xbee).
 * Copyright (c) 2019 Nebojsa Cvetkovic.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <driver/uart.h>
#include <driver/gpio.h>
#include <esp_event.h>
#include <esp_log.h>
#include <inttypes.h>
#include <string.h>
#include <protocol/nmea.h>
#include <stream_stats.h>

#include "uart.h"
#include "config.h"
#include "interface/socket_server.h"
#include "tasks.h"

static const char *TAG = "UART";

ESP_EVENT_DEFINE_BASE(UART_EVENT_READ);
ESP_EVENT_DEFINE_BASE(UART_EVENT_WRITE);

void uart_register_read_handler(esp_event_handler_t event_handler) {
    ESP_ERROR_CHECK(esp_event_handler_register(UART_EVENT_READ, ESP_EVENT_ANY_ID, event_handler, NULL));
}

void uart_unregister_read_handler(esp_event_handler_t event_handler) {
    ESP_ERROR_CHECK(esp_event_handler_unregister(UART_EVENT_READ, ESP_EVENT_ANY_ID, event_handler));
}

void uart_register_write_handler(esp_event_handler_t event_handler) {
    ESP_ERROR_CHECK(esp_event_handler_register(UART_EVENT_WRITE, ESP_EVENT_ANY_ID, event_handler, NULL));
}

void uart_unregister_write_handler(esp_event_handler_t event_handler) {
    ESP_ERROR_CHECK(esp_event_handler_unregister(UART_EVENT_WRITE, ESP_EVENT_ANY_ID, event_handler));
}

static int uart_port = -1;
static bool uart_log_forward = false;

static stream_stats_handle_t stream_stats;

static void uart_task(void *ctx);

void uart_init() {
    // Dedicated Mammotion input. UART0 remains available for USB diagnostics.
    uart_port = UART_NUM_1;

    uart_config_t uart_config = {
            .baud_rate = 460800,
            .data_bits = UART_DATA_8_BITS,
            .parity = UART_PARITY_DISABLE,
            .stop_bits = UART_STOP_BITS_1,
            .flow_ctrl = UART_HW_FLOWCTRL_DISABLE
    };
    ESP_ERROR_CHECK(uart_param_config(uart_port, &uart_config));
    ESP_ERROR_CHECK(uart_set_pin(
            uart_port,
            UART_PIN_NO_CHANGE, GPIO_NUM_16,
            UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE
    ));
    ESP_ERROR_CHECK(uart_driver_install(uart_port, UART_BUFFER_SIZE, 0, 0, NULL, 0));

    stream_stats = stream_stats_new("uart");

    xTaskCreate(uart_task, "uart_task", 8192, NULL, TASK_PRIORITY_UART, NULL);
}

static uint8_t frame[1029];
static size_t used;
static uint32_t accepted_frames, bad_crc, idle_resets;

static void ingest_rtcm(uint8_t byte) {
    if (!used && byte != 0xd3) return;
    frame[used++] = byte;
    while (used) {
        size_t length = 0;
        if (frame[0] == 0xd3) {
            if (used < 2) return;
            if ((frame[1] & 0xfc) == 0) {
                if (used < 3) return;
                length = ((size_t)frame[1] << 8) + frame[2] + 6;
                if (length < 8) {
                    length = 0;
                } else {
                    if (used < length) return;
                    uint32_t crc = 0;
                    for (size_t i = 0; i < length; ++i) {
                        crc ^= (uint32_t)frame[i] << 16;
                        for (int bit = 0; bit < 8; ++bit) {
                            crc <<= 1;
                            if (crc & 0x1000000) crc ^= 0x1864cfb;
                        }
                    }
                    if (crc == 0) {
                        ++accepted_frames;
                        esp_event_post(UART_EVENT_READ, length, frame, length, portMAX_DELAY);
                    } else {
                        ++bad_crc;
                        length = 0;
                    }
                }
            }
        }
        size_t consumed = length ? length : 1;
        used -= consumed;
        memmove(frame, frame + consumed, used);
    }
}

static void uart_task(void *ctx) {
    uint8_t buffer[UART_BUFFER_SIZE];
    TickType_t last_report = xTaskGetTickCount();

    while (true) {
        TickType_t now = xTaskGetTickCount();
        if (now - last_report >= pdMS_TO_TICKS(10000)) {
            ESP_LOGI(TAG, "RTCM accepted=%" PRIu32 " CRC failures=%" PRIu32
                     " incomplete bursts=%" PRIu32, accepted_frames, bad_crc, idle_resets);
            last_report = now;
        }
        int32_t len = uart_read_bytes(uart_port, buffer, sizeof(buffer), pdMS_TO_TICKS(50));
        if (len < 0) {
            ESP_LOGE(TAG, "Error reading from UART");
        } else if (len == 0) {
            if (used) {
                used = 0;
                ++idle_resets;
            }
            continue;
        }

        stream_stats_increment(stream_stats, len, 0);

        for (int32_t i = 0; i < len; ++i) ingest_rtcm(buffer[i]);
    }
}

void uart_inject(void *buf, size_t len) {
    (void)buf;
    (void)len;
}

int uart_log(char *buf, size_t len) {
    if (!uart_log_forward) return 0;
    return uart_write(buf, len);
}

int uart_nmea(const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);

    char *nmea;
    nmea_vasprintf(&nmea, fmt, args);
    int l = uart_write(nmea, strlen(nmea));
    free(nmea);

    va_end(args);

    return l;
}

int uart_write(char *buf, size_t len) {
    (void)buf;
    (void)len;
    return 0;
}
