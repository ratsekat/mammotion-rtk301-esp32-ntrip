/*
 * This file is part of the ESP32-XBee distribution (https://github.com/nebkat/esp32-xbee).
 * Copyright (c) 2019 Nebojsa Cvetkovic.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <esp_log.h>
#include <esp_event_base.h>
#include <sys/socket.h>
#include <wifi.h>
#include <tasks.h>
#include <status_led.h>
#include <retry.h>
#include <stream_stats.h>
#include <freertos/queue.h>
#include <esp_ota_ops.h>
#include "interface/ntrip.h"
#include "config.h"
#include "util.h"
#include "uart.h"

static const char *TAG = "NTRIP_SERVER";

#define BUFFER_SIZE 512

static status_led_handle_t status_led = NULL;
static stream_stats_handle_t stream_stats = NULL;

#define SOURCE_QUEUE_DEPTH 16
#define SOURCE_MAX_AGE_MS 3000

typedef struct {
    TickType_t captured;
    uint16_t length;
    uint8_t bytes[1029];
} source_frame_t;

static QueueHandle_t source_queue;

static void ntrip_server_uart_handler(void *args, esp_event_base_t base, int32_t length, void *buffer) {
    static source_frame_t frame;
    if (length < 8 || (size_t)length > sizeof(frame.bytes)) return;
    frame.captured = xTaskGetTickCount();
    frame.length = length;
    memcpy(frame.bytes, buffer, length);
    // A full queue drops whole frames. The UART event loop never waits on TCP.
    xQueueSend(source_queue, &frame, 0);
}

static bool write_all(int sock, const void *buffer, size_t length) {
    const uint8_t *data = buffer;
    while (length) {
        int sent = write(sock, data, length);
        if (sent <= 0) return false;
        data += sent;
        length -= sent;
    }
    return true;
}

static bool source_accepted(int sock, char *line, size_t capacity) {
    TickType_t start = xTaskGetTickCount();
    for (size_t i = 0; i + 1 < capacity; ++i) {
        if (xTaskGetTickCount() - start >= pdMS_TO_TICKS(5000)) return false;
        if (read(sock, line + i, 1) != 1) return false;
        if (line[i] != '\n') continue;
        line[i && line[i - 1] == '\r' ? i - 1 : i] = '\0';
        return strcmp(line, "OK") == 0 || strcmp(line, "ICY 200 OK") == 0 ||
               strcmp(line, "HTTP/1.1 200 OK") == 0 || strcmp(line, "HTTP/1.0 200 OK") == 0;
    }
    return false;
}

static void ntrip_server_task(void *ctx) {
    config_color_t status_led_color = config_get_color(CONF_ITEM(KEY_CONFIG_NTRIP_SERVER_COLOR));
    if (status_led_color.rgba != 0) status_led = status_led_add(status_led_color.rgba, STATUS_LED_FADE, 500, 2000, 0);
    if (status_led != NULL) status_led->active = false;

    stream_stats = stream_stats_new("ntrip_server");
    source_queue = xQueueCreate(SOURCE_QUEUE_DEPTH, sizeof(source_frame_t));
    if (source_queue == NULL) {
        ESP_LOGE(TAG, "Could not allocate RTCM source queue");
        vTaskDelete(NULL);
        return;
    }
    uart_register_read_handler(ntrip_server_uart_handler);

    retry_delay_handle_t delay_handle = retry_init(true, 5, 2000, 0);
    static source_frame_t pending;

    while (true) {
        retry_delay(delay_handle);

        wait_for_ip();
        do {
            xQueueReceive(source_queue, &pending, portMAX_DELAY);
        } while (xTaskGetTickCount() - pending.captured > pdMS_TO_TICKS(SOURCE_MAX_AGE_MS));

        char buffer[BUFFER_SIZE];
        int sock = -1;
        char *host = NULL, *mountpoint = NULL, *password = NULL;
        uint16_t port = config_get_u16(CONF_ITEM(KEY_CONFIG_NTRIP_SERVER_PORT));
        config_get_primitive(CONF_ITEM(KEY_CONFIG_NTRIP_SERVER_PORT), &port);
        config_get_str_blob_alloc(CONF_ITEM(KEY_CONFIG_NTRIP_SERVER_HOST), (void **) &host);
        config_get_str_blob_alloc(CONF_ITEM(KEY_CONFIG_NTRIP_SERVER_PASSWORD), (void **) &password);
        config_get_str_blob_alloc(CONF_ITEM(KEY_CONFIG_NTRIP_SERVER_MOUNTPOINT), (void **) &mountpoint);

        ERROR_ACTION(TAG, !host || !*host || !password || !*password || !mountpoint ||
                     !*mountpoint || *mountpoint == '/' ||
                     strpbrk(mountpoint, " /\t\r\n") || strpbrk(password, " \t\r\n"),
                     goto _error, "Check NTRIP source settings");
        ESP_LOGI(TAG, "Connecting to %s:%d/%s", host, port, mountpoint);
        sock = connect_socket(host, port, SOCK_STREAM);
        ERROR_ACTION(TAG, sock == CONNECT_SOCKET_ERROR_RESOLVE, goto _error, "Could not resolve host");
        ERROR_ACTION(TAG, sock < 0, goto _error, "Could not connect to host");

        int request_len = snprintf(buffer, sizeof(buffer), "SOURCE %s /%s" NEWLINE \
                "Source-Agent: NTRIP %s/%s" NEWLINE \
                NEWLINE, password, mountpoint, NTRIP_SERVER_NAME, esp_ota_get_app_description()->version);
        ERROR_ACTION(TAG, request_len <= 0 || (size_t)request_len >= sizeof(buffer) ||
                     !write_all(sock, buffer, request_len), goto _error, "Could not send source request");
        ERROR_ACTION(TAG, !source_accepted(sock, buffer, sizeof(buffer)), goto _error,
                     "Caster did not accept source request");

        ESP_LOGI(TAG, "Successfully connected to %s:%d/%s", host, port, mountpoint);

        retry_reset(delay_handle);

        if (status_led != NULL) status_led->active = true;

        do {
            if (xTaskGetTickCount() - pending.captured <= pdMS_TO_TICKS(SOURCE_MAX_AGE_MS)) {
                if (!write_all(sock, pending.bytes, pending.length)) break;
                stream_stats_increment(stream_stats, 0, pending.length);
            }
        } while (xQueueReceive(source_queue, &pending, pdMS_TO_TICKS(NTRIP_KEEP_ALIVE_THRESHOLD)) == pdTRUE);

        if (status_led != NULL) status_led->active = false;

        ESP_LOGW(TAG, "Disconnected from %s:%d/%s", host, port, mountpoint);
        _error:
        destroy_socket(&sock);

        free(host);
        free(mountpoint);
        free(password);
    }
}

void ntrip_server_init() {
    if (!config_get_bool1(CONF_ITEM(KEY_CONFIG_NTRIP_SERVER_ACTIVE))) return;

    xTaskCreate(ntrip_server_task, "ntrip_server_task", 4096, NULL, TASK_PRIORITY_INTERFACE, NULL);
}
