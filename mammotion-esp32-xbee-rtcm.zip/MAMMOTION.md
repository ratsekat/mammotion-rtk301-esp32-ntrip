# Mammotion RTK301 source bridge

This ESP32 XBee adaptation targets the external ESP32-WROOM-32 development
board. Use the confirmed data output and common ground. The data input is
GPIO16 at 460800 baud, 8N1. Leave the development board's TX and power pins
disconnected from the base.

This build fixes the capture settings in main/uart.c. The generic web UI
still displays UART settings, but those fields do not change the capture
port. The input parser emits only complete CRC24Q-valid RTCM3 frames.

The RTCM filter passes all CRC-valid RTCM3 message types. The supplied captures
contained 1006 (reference position and antenna height), 1033 (descriptor),
and MSM3 observations 1073, 1083, 1093 and 1123. Type 1230 (GLONASS bias)
was absent from those captures. It will pass through if the base emits it.
Check that your rover supports MSM3.

Build with ESP-IDF 4.4 for the esp32 target using `idf.py build` from this
directory. A PlatformIO ESP-IDF environment is also included (`pio run`).
On Windows, a short project and toolchain path helps with legacy package
extraction. For a native ESP-IDF build, close Arduino Serial Monitor, verify
COM5 identifies the external ESP32, and run `idf.py -p COM5 flash monitor`.
The flash must include the generated www SPIFFS image for the web interface.

Connect to the ESP32 setup hotspot and open http://192.168.4.1. In the web UI,
configure Wi-Fi Station, then enable NTRIP Server (source mode). Use
rtk2go.com, port 2101, the registered mountpoint without a leading slash,
and its Rev1 source password. Leave other bridge interfaces disabled.
Secure the setup hotspot and admin access before leaving the device online.
The mountpoint publishes the reference coordinates carried by RTCM.

The NTRIP task buffers up to 16 complete frames, drops new frames if the queue
is full, and skips queued frames older than three seconds. The USB console
at 115200 reports valid-frame and CRC counts every 10 seconds. Verify a
successful source connection and a stable RTK Fixed solution at your rover.
